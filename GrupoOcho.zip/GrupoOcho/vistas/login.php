<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>SMS MARKETING</title>
	<link rel="icon" href="../img/iconos/logo.ico">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<!-- <link rel="stylesheet" href="css/estilo2.css">
	<link rel="stylesheet" href="css/estilo1.css"> -->
	<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<!-- Menu -->
	<div class="container">
		<header>
			<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
                        <!--
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
							<span class="sr-only">Menu</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
                    -->
						<a href="../index.php" class="navbar-brand">SMS Marketing</a>
					</div>
				</div>
			</nav>
		</header>
	</div>
<!-- Formulario de Sesion-->
		 <br><br><br>
		 <div class="row">
		                     <div class="col-md-4"></div>
		                     <div class="col-md-4">
		                         <div class="well"> <!--hace un sombreado a la columna-->
		                             <center>
		 <div class="well">
		 <form action="../procesos/validar1.php" method="post" enctype="application/x-www-form-urlencoded">
		     <h2>LOGIN</h2>
		     <input type="text" placeholder="&#128272; Usuario" name="usuario">
		     <input type="password" placeholder="&#128272; Contraseña" name="password">
		     <input type="submit" value="Ingresar">
		 </form>
		 </div>
	 </center>
</div>
</div>
<div class="col-md-4"></div>
</div>
<br>
<!-- contactos -->
<footer>
       <div class="container-footer-all">
            <div class="container-body">
                <div class="colum1">
                    <h1>Mas informacion de la compañia</h1>
							<p>Esta compañía se dedica a el envío masivo de mensajes sobre publicidad y o promociones de diferentes compañías telefónicas.</p>
                </div>
                <div class="colum2">
                    <h1>Redes Sociales</h1>
                    <div class="row">
                        <img src="../img/iconos/facebook.png">
                        <label>Siguenos en Facebook</label>
                    </div>
                    <div class="row">
                        <img src="../img/iconos/twitter.png">
                        <label>Siguenos en Twitter</label>
                    </div>
                    <div class="row">
                        <img src="../img/iconos/instagram.png">
                        <label>Siguenos en Instagram</label>
                    </div>
                    <div class="row">
                        <img src="../img/iconos/google-plus.png">
                        <label>Siguenos en Google Plus</label>
                    </div>
                    <div class="row">
                        <img src="../img/iconos/pinterest.png">
                        <label>Siguenos en Pinteres</label>
                    </div>
                </div>
                <div class="colum3">
                    <h1>Informacion Contactos</h1>
                    <div class="row2">
                        <img src="../img/iconos/house.png">
                        <label>Residencial Alpes Suizos II pasaje Lisboa casa numero 16 pol G</label>
                    </div>
                    <div class="row2">
                        <img src="../img/iconos/smartphone.png">
                        <label>+503 7815 8879</label>
                    </div>

                    <div class="row2">
                        <img src="../img/iconos/contact.png">
                         <label>MensajeriaSMS@gmail.com</label>
                    </div>

                </div>

            </div>

        </div>

        <div class="container-footer">
               <div class="footer">
                    <div class="copyright">
                        © 2018 Todos los Derechos Reservados | <a href="">SMS MARKETING</a>
                    </div>

                    <div class="information">
                        <a href="">Informacion Compañia</a> | <a href="">Privacion y Politica</a> | <a href="">Terminos y Condiciones</a>
                    </div>
                </div>

            </div>

    </footer>
	<!-- Librerias -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
