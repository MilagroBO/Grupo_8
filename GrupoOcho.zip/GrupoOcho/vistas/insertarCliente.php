<?php
include_once "../clases/conexion.php";
include "../procesos/nuevoCliente.php";

 $proceso = new Procesos($bdConexion->obtenerConexion());
 if(isset($_POST['btnGuardar'])){
         $slcCompania = $_POST['slcCompania'];
         $txtNombre   = $_POST['txtNombre'];
         $txtTelefono = $_POST['txtTelefono'];
     //LLAMADA AL METODO DE INSERCION
     $proceso->insertar($slcCompania,$txtNombre,$txtTelefono);
     }
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
      <link rel="icon" href="../img/iconos/logo.ico">
      <title>SMS MARKETING</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/estilo1.css">
	    <link rel="stylesheet" href="../css/estilo2.css">
  </head>

<!-- Menu -->
  <div class="container">
    <header>
      <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
              <span class="sr-only">Menu</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="../index.php" class="navbar-brand">SMS Marketing</a>
          </div>
          <div class="collapse navbar-collapse" id="navbar-1" >
            <ul class="nav navbar-nav">
              <li><a href="insertarCompa.php">Nueva Compañia</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarRepresentante.php">Nuevo Representante</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarMensaje.php">Nuevo Mensaje</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarEnvio.php">Nuevo Envio</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarContrato.php">Nuevo Contrato</a></li>
            </ul>
<!--- Menu derecha-->
            </div>
        </div>
      </nav>
    </header>
  </div>


  <body align="center" ><br><br><br>
    <div class="bg-danger" align="center">
      <br>
      <h3><strong>Nuevo Cliente<br>&nbsp;</strong></h3>
    </div>
    <div class="well">
      <form action="" method="post">
          <img src="../img/cliente.jpg" class="img-circle" width="150" height="150">
          <p><strong>COMPANIA</strong></p>
          <select name="slcCompania" id="slcCompania">
            <?php
            //Llamada al metodo de lineas del select
            $proceso->mostrar();
            ?>
          </select>
          <p><strong>NOMBRE</strong></p>
          <input type="text" name="txtNombre" required>
          <p><strong>TELEFONO</strong></p>
          <input type="text" name="txtTelefono" required><br><br>
          <input type="submit" name="btnGuardar" id="btnGuardar" value="Guardar" class="btn btn-success">
        </form>
    </div>


    <footer>
           <div class="container-footer-all">
                <div class="container-body">
                    <div class="colum1">
                        <h1>Mas informacion de la compañia</h1>
    							<p>Esta compañía se dedica a el envío masivo de mensajes sobre publicidad y o promociones de diferentes compañías telefónicas.</p>
                    </div>
                    <div class="colum2">
                        <h1>Redes Sociales</h1>
                        <div class="row">
                            <img src="../img/iconos/facebook.png">
                            <label>Siguenos en Facebook</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/twitter.png">
                            <label>Siguenos en Twitter</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/instagram.png">
                            <label>Siguenos en Instagram</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/google-plus.png">
                            <label>Siguenos en Google Plus</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/pinterest.png">
                            <label>Siguenos en Pinteres</label>
                        </div>
                    </div>
                    <div class="colum3">
                        <h1>Informacion Contactos</h1>
                        <div class="row2">
                            <img src="../img/iconos/house.png">
                            <label>Residencial Alpes Suizos II pasaje Lisboa casa numero 16 pol G</label>
                        </div>
                        <div class="row2">
                            <img src="../img/iconos/smartphone.png">
                            <label>+503 7815 8879</label>
                        </div>

                        <div class="row2">
                            <img src="../img/iconos/contact.png">
                             <label>MensajeriaSMS@gmail.com</label>
                        </div>

                    </div>

                </div>

            </div>

            <div class="container-footer">
                   <div class="footer">
                        <div class="copyright">
                            © 2018 Todos los Derechos Reservados | <a href="">SMS MARKETING</a>
                        </div>

                        <div class="information">
                            <a href="">Informacion Compañia</a> | <a href="">Privacion y Politica</a> | <a href="">Terminos y Condiciones</a>
                        </div>
                    </div>

                </div>

        </footer>

     <script src="../js/jquery-3.2.1.min.js"></script>
     <script src="../js/bootstrap.min.js"></script>
  </body>
</html>
