<?php
 include_once "../clases/conexion.php";
 include "../procesos/nuevoEnvio.php";

 $proceso = new Procesos($bdConexion->obtenerConexion());
 if(isset($_POST['btnGuardar'])){
         $txtAsunto   = $_POST['txtAsunto'];
         $txtContenido= $_POST['txtContenido'];
         $txtFecha    = $_POST['txtFecha'];
         $txtNombre   = $_POST['txtNombre'];
     //LLAMADA AL METODO DE INSERCION
     $proceso->insertar($txtAsunto,$txtContenido,$txtFecha,$txtNombre);
     }
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>SMS MARKETING</title>
    <link rel="icon" href="../img/iconos/logo.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/estilo2.css">
    <link rel="stylesheet" href="../css/estilo1.css">
  </head>
<!-- Menu -->
  <div class="container">
    <header>
      <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
              <span class="sr-only">Menu</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="../index.php" class="navbar-brand">SMS Marketing</a>
          </div>
          <div class="collapse navbar-collapse" id="navbar-1" >
            <ul class="nav navbar-nav">
              <li><a href="insertarCompa.php">Nueva Compañia</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarCliente.php">Nuevo Cliente</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarRepresentante.php">Nuevo Representante</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarEnvio.php">Nuevo Envio</a></li>
            </ul>
            <ul class="nav navbar-nav">
              <li><a href="insertarContrato.php">Nuevo Contrato</a></li>
            </ul>
<!--- Menu derecha-->
            </div>
        </div>
      </nav>
    </header>
  </div>


  <body align="center"><br><br><br>
  <div class="bg-danger" align="center">
    <br>
    <h3><strong>Nuevo Mensaje<br>&nbsp;</strong></h3>
  </div>
  <div class="well">
  <form action="" method="post">
          <img src="../img/notificacion.gif" class="img-circle" width="150" height="150">
      <p><br><strong>ASUNTO</strong></p>
      <input type="text" name="txtAsunto" required>
      <p><strong>CONTENIDO</strong></p>
      <textarea rows="4" cols="75" name="txtContenido" maxlength="250" required></textarea>
      <p><strong>FECHA</strong></p>
      <input name="txtFecha" type="text" class="fecha" id="txtFecha" value="<?= date('d-m-Y'); ?>" readonly="readonly" />
      <p><strong>NOMBRE</strong></p>
      <input type="text" name="txtNombre" required>
      <input type="submit" name="btnGuardar" id="btnGuardar" value="Guardar" class="btn btn-primary">
    </form>
  </div>

    <!-- contactos -->
    <footer>
           <div class="container-footer-all">
                <div class="container-body">
                    <div class="colum1">
                        <h1>Mas informacion de la compañia</h1>
    							<p>Esta compañía se dedica a el envío masivo de mensajes sobre publicidad y o promociones de diferentes compañías telefónicas.</p>
                    </div>
                    <div class="colum2">
                        <h1>Redes Sociales</h1>
                        <div class="row">
                            <img src="../img/iconos/facebook.png">
                            <label>Siguenos en Facebook</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/twitter.png">
                            <label>Siguenos en Twitter</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/instagram.png">
                            <label>Siguenos en Instagram</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/google-plus.png">
                            <label>Siguenos en Google Plus</label>
                        </div>
                        <div class="row">
                            <img src="../img/iconos/pinterest.png">
                            <label>Siguenos en Pinteres</label>
                        </div>
                    </div>
                    <div class="colum3">
                        <h1>Informacion Contactos</h1>
                        <div class="row2">
                            <img src="../img/iconos/house.png">
                            <label>Residencial Alpes Suizos II pasaje Lisboa casa numero 16 pol G</label>
                        </div>
                        <div class="row2">
                            <img src="../img/iconos/smartphone.png">
                            <label>+503 7815 8879</label>
                        </div>

                        <div class="row2">
                            <img src="../img/iconos/contact.png">
                             <label>MensajeriaSMS@gmail.com</label>
                        </div>

                    </div>

                </div>

            </div>

            <div class="container-footer">
                   <div class="footer">
                        <div class="copyright">
                            © 2018 Todos los Derechos Reservados | <a href="">SMS MARKETING</a>
                        </div>

                        <div class="information">
                            <a href="">Informacion Compañia</a> | <a href="">Privacion y Politica</a> | <a href="">Terminos y Condiciones</a>
                        </div>
                    </div>

                </div>

        </footer>
  <!-- Librerias -->
  <script src="../js/jquery-3.2.1.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  </body>
</html>
