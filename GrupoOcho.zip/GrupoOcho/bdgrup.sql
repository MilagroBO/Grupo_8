-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-11-2018 a las 09:12:59
-- Versión del servidor: 10.1.34-MariaDB
-- Versión de PHP: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdgrup`
--
CREATE DATABASE IF NOT EXISTS `bdgrup` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bdgrup`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `IDCliente` int(11) NOT NULL,
  `IDCompania` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`IDCliente`, `IDCompania`, `Nombre`, `Telefono`) VALUES
(3, 1, 'CLARO-SLV', '2257-5661'),
(4, 2, 'TIGO-SLV', '2289-6705'),
(5, 10, 'MOVISTAR-SLV', '2288-9166');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compania`
--

CREATE TABLE `compania` (
  `IDCompania` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `compania`
--

INSERT INTO `compania` (`IDCompania`, `Nombre`) VALUES
(1, '1. CLARO'),
(2, '2. TIGO'),
(3, '3. DIGICEL'),
(4, '4. MOVISTAR'),
(5, '5. RED'),
(6, '6. TELCELMEX'),
(7, '7. at&t'),
(8, '8. T-MOBILE'),
(9, '9. SPRINT'),
(10, '11.EduarNet');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contrato`
--

CREATE TABLE `contrato` (
  `IDContrato` int(11) NOT NULL,
  `IDUsuario` int(11) NOT NULL,
  `IDMensaje` int(11) NOT NULL,
  `DUI` int(11) NOT NULL,
  `IDCliente` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `Telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `contrato`
--

INSERT INTO `contrato` (`IDContrato`, `IDUsuario`, `IDMensaje`, `DUI`, `IDCliente`, `Nombre`, `Direccion`, `Telefono`) VALUES
(5, 4, 4, 87695214, 3, 'PROPAGANDA TELEFONICA', '4TA, AV NTE. #98 COL MIRALVALLE, SAN SALVADOR', '2258-4894'),
(6, 4, 4, 87695214, 3, 'CITAS EN LINEA', '6TA CALLE PTE, B.MODELO, SAN SALVADOR. EL SALVADOR', '2318-1365'),
(7, 4, 3, 87695214, 4, 'HABLA GRATIS', '6TA CALLE PTE, B.LAS AMERICAS, SAN SALVADOR. EL SA', '2214-5869');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `envios`
--

CREATE TABLE `envios` (
  `IDEnvios` int(11) NOT NULL,
  `IDMensaje` int(11) NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `IDCompania` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `envios`
--

INSERT INTO `envios` (`IDEnvios`, `IDMensaje`, `Nombre`, `Fecha`, `IDCompania`) VALUES
(1, 3, 'OFERTAS', '0000-00-00', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `IDMensaje` int(11) NOT NULL,
  `Asunto` varchar(50) NOT NULL,
  `Contenido` varchar(250) NOT NULL,
  `Fecha` date NOT NULL,
  `Nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`IDMensaje`, `Asunto`, `Contenido`, `Fecha`, `Nombre`) VALUES
(1, 'SOLO HOY!', 'APROVECHA TU OPORTUNIDAD A RECARGAR HOY MISMO, 2BLE SALDO EN TUS RECARGAS DESDE $1.00...!', '0000-00-00', 'DOBLE SALDO CLARO'),
(3, 'SOLO HOY!', 'APROVECHA TU OPORTUNIDAD A RECARGAR HOY MISMO, 2BLE SALDO EN TUS RECARGAS DESDE $1.00...!', '0000-00-00', 'DOBLE SALDO TIGO'),
(4, 'SOLO HOY!', 'APROVECHA TU OPORTUNIDAD A RECARGAR HOY MISMO, 2BLE SALDO EN TUS RECARGAS DESDE $1.00...!', '2018-10-25', 'DOBLE SALDO DIGICEL'),
(5, 'SOLO HOY!', 'APROVECHA TU OPORTUNIDAD A RECARGAR HOY MISMO, 2BLE SALDO EN TUS RECARGAS DESDE $1.00...!', '2018-10-25', 'DOBLE SALDO MOVISTAR'),
(6, 'DESCARGA!', 'APROVECHA TU OPORTUNIDAD Y DESCARGA TODOS TUS JUEGOS FAVORITOS DE NUESTRA PLATAFORMA, ENVIA LA PALABRA YA AL 7777 $0.25 X MSJ!', '2017-12-03', 'OFERTA CLARO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `representantes`
--

CREATE TABLE `representantes` (
  `DUI` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Puesto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `representantes`
--

INSERT INTO `representantes` (`DUI`, `Nombre`, `Apellido`, `Puesto`) VALUES
(12345678, 'EDUARDO', 'TECH', 'GERENTE REGIONAL'),
(25631758, 'Jose Alejandro', 'Galvez', 'Gerente de sucursal'),
(87695214, 'Diego Ernesto', 'Aparicio Hernandez', 'Ejecutivo'),
(89542365, 'Karla Maria', 'Lopez', 'Despachadora'),
(93255562, 'Armando Jose', 'Lopez Arevalo', 'Presidente corporativo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `IDRol` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`IDRol`, `Nombre`) VALUES
(1, 'ADMINISTRADOR'),
(2, 'USUARIO'),
(3, 'CLIENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `IDUsuario` int(11) NOT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Clave` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  `IDRol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`IDUsuario`, `Nombre`, `Clave`, `IDRol`) VALUES
(1, 'Oscar Hernandez', '123456', 1),
(2, 'Manuel Gomez', '123456', 1),
(3, 'Christian Calderon', '123456', 2),
(4, 'Jose Sixco', '123456', 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`IDCliente`),
  ADD KEY `IDCompania` (`IDCompania`);

--
-- Indices de la tabla `compania`
--
ALTER TABLE `compania`
  ADD PRIMARY KEY (`IDCompania`);

--
-- Indices de la tabla `contrato`
--
ALTER TABLE `contrato`
  ADD PRIMARY KEY (`IDContrato`),
  ADD KEY `IDUsuario` (`IDUsuario`),
  ADD KEY `IDMensaje` (`IDMensaje`),
  ADD KEY `DUI` (`DUI`),
  ADD KEY `IDCliente` (`IDCliente`);

--
-- Indices de la tabla `envios`
--
ALTER TABLE `envios`
  ADD PRIMARY KEY (`IDEnvios`),
  ADD KEY `envios_ibfk_2` (`IDMensaje`),
  ADD KEY `envios_ibfk_3` (`IDCompania`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`IDMensaje`);

--
-- Indices de la tabla `representantes`
--
ALTER TABLE `representantes`
  ADD PRIMARY KEY (`DUI`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`IDRol`) USING BTREE;

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`IDUsuario`),
  ADD KEY `ROLID` (`IDRol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `IDCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `compania`
--
ALTER TABLE `compania`
  MODIFY `IDCompania` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `contrato`
--
ALTER TABLE `contrato`
  MODIFY `IDContrato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `envios`
--
ALTER TABLE `envios`
  MODIFY `IDEnvios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `IDMensaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `IDRol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `IDUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_2` FOREIGN KEY (`IDCompania`) REFERENCES `compania` (`IDCompania`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `contrato`
--
ALTER TABLE `contrato`
  ADD CONSTRAINT `clientesid` FOREIGN KEY (`IDCliente`) REFERENCES `cliente` (`IDCliente`),
  ADD CONSTRAINT `negocios_ibfk_1` FOREIGN KEY (`IDUsuario`) REFERENCES `usuarios` (`IDUsuario`),
  ADD CONSTRAINT `negocios_ibfk_3` FOREIGN KEY (`IDMensaje`) REFERENCES `mensajes` (`IDMensaje`),
  ADD CONSTRAINT `negocios_ibfk_4` FOREIGN KEY (`DUI`) REFERENCES `representantes` (`DUI`);

--
-- Filtros para la tabla `envios`
--
ALTER TABLE `envios`
  ADD CONSTRAINT `envios_ibfk_2` FOREIGN KEY (`IDMensaje`) REFERENCES `mensajes` (`IDMensaje`),
  ADD CONSTRAINT `envios_ibfk_3` FOREIGN KEY (`IDCompania`) REFERENCES `compania` (`IDCompania`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`IDRol`) REFERENCES `roles` (`IDRol`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
