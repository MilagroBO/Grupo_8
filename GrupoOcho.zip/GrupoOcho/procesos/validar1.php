<?php
session_start();
$usuario=$_POST['usuario'];
$contra=$_POST['password'];
//conectando a la base
$conexion = mysqli_connect('localhost','root','','bdgrup')or die('No se puede conectar a la base de datos'.mysqli_error($conexion));;

$consulta="select * from usuarios where Nombre='$usuario' and Clave= '$contra'";

$resultado = mysqli_query($conexion, $consulta);
$filas=mysqli_num_rows($resultado);
if($filas>0){
    header('location: ../vistas/insertarCompa.php');
}else{
  echo "<script>alert('¡INFORMACIÓN ERRONEA!')</script>";
  echo "<script> window.open('../vistas/login.php','_self')</script>";
}
