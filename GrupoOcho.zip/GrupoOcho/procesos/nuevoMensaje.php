<?php
class Procesos{
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }
  public function insertar($txtAsunto,$txtContenido,$txtFecha,$txtNombre){
    $sql = "INSERT INTO mensajes (Asunto,Contenido,Fecha,Nombre) VALUES ('".$txtAsunto."','".$txtContenido."','".$txtFecha."','".$txtNombre."')";
    $rs = mysqli_query($this->Enlace,$sql);
    if ($rs){
      echo "<script> alert('¡El mensaje a sido enviado!')</script>";
    }
  }//Fin de metodo insertar
}
