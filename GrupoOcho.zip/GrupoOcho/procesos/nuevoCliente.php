<?php
class Procesos{
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }
  public function mostrar(){
  	$sql = "SELECT IDCompania,Nombre FROM compania";
  	$rs = mysqli_query($this->Enlace,$sql);
  	while($fila = mysqli_fetch_array($rs))
  	{
  		print "<option value=".$fila['IDCompania'].">".$fila['Nombre']."</option>";
    }
  }
 public function insertar($slcCompania,$txtNombre,$txtTelefono){
       $sql = "INSERT INTO cliente (IDCompania,Nombre,Telefono) VALUES ('".$slcCompania."','".$txtNombre."','".$txtTelefono."')";
       $rs = mysqli_query($this->Enlace,$sql);
       if ($rs){
         echo "<script> alert('El cliente a sido agregado')</script>";
       }
     }
}
