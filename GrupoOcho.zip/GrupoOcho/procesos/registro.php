<!DOCTYPE html>
<html>
<head>
	<metha charset ="utf-8">
	<title>Inicio de Sesion</title>
	<link rel="icon" href="img/logo.ico">
	<link rel="stylesheet" href="css/estilo1.css">
</head>
<body>
	<?php
	session_start();
	ob_start();

	if(isset($_POST['btnIngresar']))//Verifico que el boton "iniciar sesion" fue oprimido
    {
      $_SESSION['sesion_exito']=0;

      $user = $_POST['txtUsuario'];
      $pass = $_POST['txtPass'];

      $_SESSION['usuarioid'] = "";
      $_SESSION['nombre1'] = "";
      $_SESSION['rol'] = "";

      if($user=="" || $pass=="")
      {
        $_SESSION['sesion_exito']=2;//2 sera error de campos vacios
      }
      else
      {
        include("../clases/abrir_conexion.php");
        $_SESSION['sesion_exito']=3;//3 Datos Incorrectos
        $resultados = mysqli_query($conexion,"SELECT * FROM $tabla_db2 WHERE Nombre = '$user' AND Clave = '$pass'");
        while($consulta = mysqli_fetch_array($resultados))
            {
              if ($_SESSION['rol'] = $consulta['IDRol']==1) {
                $_SESSION['sesion_exito']=1;//Inicio Sesion :D
               header('location: http://localhost/GrupOcho/vistas/usuarioMenu.php');
               $_SESSION['usuarioid'] =$consulta['IDRol'];
               $_SESSION['nombre1'] = $consulta['Nombre'];
              }elseif ($_SESSION['rol'] = $consulta['IDRol']==2)
              {
                $_SESSION['sesion_exito']=1;//Inicio Sesion :D
               header('location: http://localhost/GrupOcho/vistas/administradorMenu.php');
               $_SESSION['usuarioid'] =$consulta['IDRol'];
               $_SESSION['nombre1'] = $consulta['Nombre'];
              }



                           }
       include("../clases/cerrar_conexion.php");
      }
    }

    if($_SESSION['sesion_exito']<>1)
    {
      header('Location:../login.php');
    }



	?>

</html>
</body>
</html>
