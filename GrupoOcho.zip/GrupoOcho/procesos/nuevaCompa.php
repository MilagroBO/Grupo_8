<?php
class Procesos{
  public  $link;
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }

 public function mostrar(){
 	$sql = "SELECT IDCompania,Nombre FROM compania";
 	$rs = mysqli_query($this->Enlace,$sql);
 	while($fila = mysqli_fetch_array($rs))
 	{
 		print "<option value=".$fila['IDCompania'].">".$fila['Nombre']."</option>";
  }
}
   //Metodo de insertado
 public function insertar($txtNueva){
       $sql = "INSERT INTO compania (Nombre) VALUES ('".$txtNueva."')";
       $rs = mysqli_query($this->Enlace,$sql);
       if ($rs){
         echo "<script> alert('La Compania a sido agregada')</script>";
       }
     }//Fin de metodo insertar
   }
