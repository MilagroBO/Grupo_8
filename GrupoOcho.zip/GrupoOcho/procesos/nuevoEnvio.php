<?php
class Procesos{
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }
  public function mostrar(){
    $sql = "SELECT IDMensaje,Nombre FROM mensajes";
    $rs = mysqli_query($this->Enlace,$sql);
    while($fila = mysqli_fetch_array($rs))
    {
      print "<option value=".$fila['IDMensaje'].">".$fila['Nombre']."</option>";
    }
  }
  public function mostrarCompa(){
  	$sql = "SELECT IDCompania,Nombre FROM compania";
  	$rs = mysqli_query($this->Enlace,$sql);
  	while($fila = mysqli_fetch_array($rs))
  	{
  		print "<option value=".$fila['IDCompania'].">".$fila['Nombre']."</option>";
   }
 }
 public function insertar($slcMensaje,$txtNombre,$txtFecha,$slcCompania){
       $sql = "INSERT INTO envios(IDMensaje,Nombre,Fecha,IDCompania) VALUES ('".$slcMensaje."','".$txtNombre."','".$txtFecha."','".$slcCompania."')";
       $rs = mysqli_query($this->Enlace,$sql);
       if ($rs){
         echo "<script> alert('Se a hecho el envio')</script>";
       }
     }//Fin de metodo insertar
   }
