<?php
class Procesos{
  public  $link;
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }
   //Metodo de insertado
 public function insertar($txtDUI,$txtNomRepre,$txtApeRepre,$txtPuesto){
       $sql = "INSERT INTO representantes(DUI,Nombre,Apellido,Puesto) VALUES ('".$txtDUI."','".$txtNomRepre."','".$txtApeRepre."','".$txtPuesto."')";
       $rs = mysqli_query($this->Enlace,$sql);
       if ($rs){
         echo "<script> alert('La Compania a sido agregada')</script>";
       }
     }//Fin de metodo insertar
   }
