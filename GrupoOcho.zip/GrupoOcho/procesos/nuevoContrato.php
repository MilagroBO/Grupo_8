<?php
class Procesos{
  private $enlace;
  function __construct($conexion)	{
    $this->Enlace = $conexion;
  }
  public function usuario(){
    $sql = "SELECT IDUsuario,Nombre FROM usuarios";
    $rs = mysqli_query($this->Enlace,$sql);
    while($fila = mysqli_fetch_array($rs))
    {
      print "<option value=".$fila['IDUsuario'].">".$fila['Nombre']."</option>";
    }
  }
  public function mensaje(){
    $sql = "SELECT IDMensaje,Nombre FROM mensajes";
    $rs = mysqli_query($this->Enlace,$sql);
    while($fila = mysqli_fetch_array($rs))
    {
      print "<option value=".$fila['IDMensaje'].">".$fila['Nombre']."</option>";
    }
  }
  public function representante(){
    $sql = "SELECT DUI, Nombre, Apellido FROM representantes";
    $rs = mysqli_query($this->Enlace,$sql);
    while($fila = mysqli_fetch_array($rs))
    {
      print "<option value=".$fila['DUI'].">".$fila['Nombre']." ".$fila['Apellido']."</option>";
    }
  }
  public function cliente(){
    $sql = "SELECT IDCliente,Nombre FROM cliente";
    $rs = mysqli_query($this->Enlace,$sql);
    while($fila = mysqli_fetch_array($rs))
    {
      print "<option value=".$fila['IDCliente'].">".$fila['Nombre']."</option>";
    }
  }
  public function mostrarCompa(){
  	$sql = "SELECT IDCompania,Nombre FROM compania";
  	$rs = mysqli_query($this->Enlace,$sql);
  	while($fila = mysqli_fetch_array($rs))
  	{
  		print "<option value=".$fila['IDCompania'].">".$fila['Nombre']."</option>";
   }
 }
 public function insertar($slcUsuario,$slcMensaje,$slcRepresentante,$slcCliente,$txtNombre,$txtDireccion,$txtTelefono){
       $sql = "INSERT INTO contrato(IDUsuario,IDMensaje,DUI,IDCliente,Nombre, Direccion,Telefono) VALUES ('".$slcUsuario."','".$slcMensaje."','".$slcRepresentante."','".$slcCliente."','".$txtNombre."','".$txtDireccion."','".$txtTelefono."')";
       $rs = mysqli_query($this->Enlace,$sql);
       if ($rs){
         echo "<script> alert('Se a ingresado el contrato')</script>";
       }
     }//Fin de metodo insertar
   }
