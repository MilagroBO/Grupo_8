<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="icon" href="img/iconos/logo.ico">
	<title>SMS MARKETING</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/estilo1.css">
	<link rel="stylesheet" href="css/estilo2.css">
	<link rel="stylesheet" href="css/estilos.css">
	<link rel="stylesheet" href="css/styles.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<div class="container">
	<header>
		<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1">
						<span class="sr-only">Menu</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="" class="navbar-brand">SMS Marketing</a>
				</div>
					<div class="collapse navbar-collapse" id="navbar-1" >
<!--- Menu derecha-->
						<ul class="nav navbar-nav navbar-right">
							<li class="active"><a href="vistas/login.php">Iniciar Sesión</a></li>
						</ul>
					</div>
			</div>
		</nav>

</div>
<!--banner-->
<div class="contenedor">
	<br><br><br>
	<div class="col-md-12">
		<div id="carousel-1" class="carousel slide" data-ride="carousel">
			<!-- Indicadores -->
			<ol class="carousel-indicators">
				<li data-target="#carousel-1" data-slide-to="0"	class="active" ></li>
				<li data-target="#carousel-1" data-slide-to="1"	></li>
			</ol>
			<!-- contenedor de los slide -->

			<div class="carousel-inner" role="listbox">
				<!-- #1 -->
				<div class="item  active">
					<img src="img/01fina.jpg" class="img-responsive" alt=""> <!-- style="width:822px;height:322px;" --> <!-- YA ME QUEDO CLARO POR QUE TODAS LAS IMAGENES MISMO TAMAÑO -->
					<div class="carousel-caption">
						<!-- <h3>Este es nuestro Slide #1</h3>
						<p>Lorem ipsum dolor sit amet.</p> -->
					</div>
				</div>
				<!-- #2 -->
				<div class="item ">
					<img src="img/02fina.jpg" class="img-responsive" alt="">
					<div class="carousel-caption">
						<!-- <h3>Este es nuestro Slide #2</h3>
						<p>Lorem ipsum dolor sit amet.</p> -->
					</div>
				</div>

			</div>
			<!-- Controles -->
			<a href="#carousel-1" class="left carousel-control" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				<span class="sr-only">Anterior</span>
			</a>
			<a href="#carousel-1" class="right carousel-control" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				<span class="sr-only">Siguiente</span>
			</a>
		</div>
	</div>
</div>
	</header>
<body>
&nbsp;
<footer>
       <div class="container-footer-all">
            <div class="container-body">
                <div class="colum1">
                    <h1>Mas informacion de la compañia</h1>
							<p>Esta compañía se dedica a el envío masivo de mensajes sobre publicidad y o promociones de diferentes compañías telefónicas.</p>
                </div>
                <div class="colum2">
                    <h1>Redes Sociales</h1>
                    <div class="row">
                        <img src="img/iconos/facebook.png">
                        <label>Siguenos en Facebook</label>
                    </div>
                    <div class="row">
                        <img src="img/iconos/twitter.png">
                        <label>Siguenos en Twitter</label>
                    </div>
                    <div class="row">
                        <img src="img/iconos/instagram.png">
                        <label>Siguenos en Instagram</label>
                    </div>
                    <div class="row">
                        <img src="img/iconos/google-plus.png">
                        <label>Siguenos en Google Plus</label>
                    </div>
                    <div class="row">
                        <img src="img/iconos/pinterest.png">
                        <label>Siguenos en Pinteres</label>
                    </div>
                </div>
                <div class="colum3">
                    <h1>Informacion Contactos</h1>
                    <div class="row2">
                        <img src="img/iconos/house.png">
                        <label>Residencial Alpes Suizos II pasaje Lisboa casa numero 16 pol G</label>
                    </div>
                    <div class="row2">
                        <img src="img/iconos/smartphone.png">
                        <label>+503 7815 8879</label>
                    </div>

                    <div class="row2">
                        <img src="img/iconos/contact.png">
                         <label>MensajeriaSMS@gmail.com</label>
                    </div>

                </div>

            </div>

        </div>

        <div class="container-footer">
               <div class="footer">
                    <div class="copyright">
                        © 2018 Todos los Derechos Reservados | <a href="">SMS MARKETING</a>
                    </div>

                    <div class="information">
                        <a href="">Informacion Compañia</a> | <a href="">Privacion y Politica</a> | <a href="">Terminos y Condiciones</a>
                    </div>
                </div>

            </div>

    </footer>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
